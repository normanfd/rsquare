<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShoesCategory extends Model
{
    //
}
