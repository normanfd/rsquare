<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ColorCardigan extends Model
{
    //
}
