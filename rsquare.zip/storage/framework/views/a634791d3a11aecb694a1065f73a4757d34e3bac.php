<!-- Mendapatkan data available product -->


<?php $__env->startSection('content'); ?>
<div class="m-content">

    <!--begin:: Widgets/New Users-->
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        View Cardigan Product
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                    <!--begin::Widget 14-->
                    <?php $__currentLoopData = $cardigan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__img m-widget4__img--pic">
                                <img src="../storage/<?php echo e($produk->cardigan_image); ?>" alt="" width="50" height="50">
                            </div>
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($produk->cardigan_name); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    harga produk : <?php echo e($produk->cardigan_price); ?>

                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="<?php echo e(route('admin.Editcustomcardigan', $produk->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <form action="<?php echo e(route('admin.Deletecustomcardigan', $produk->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class="m-btn  btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
    
    
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>