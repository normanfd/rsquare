Cardigan Order detail
id cardigan :<?php echo e($single_cardigan->id); ?>