<?php $__env->startSection('content'); ?>

  <!--================Checkout Area =================-->
  <section class="checkout_area section_padding">
    <div class="container">
      <div class="billing_details">
        <div class="row">
          <div class="col-lg-8">
            <h4>Order Jacket Details</h4>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form class="row contact_form" action="<?php echo e(route('post.user.order.jacket', $jacket->id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="col-md-6 form-group p_star">
                <input type="text" class="form-control" id="wa_number" name="wa_number" placeholder="Nomor Whatsapp" required/>
              </div>
              
              <div class="col-md-6 form-group p_star">
                <input type="text" class="form-control" id="user_id" name="user_id" value="Nama Anda = <?php echo e(Auth::getUser()->name); ?>" readonly/>
              </div>

              <div class="col-md-6 form-group p_star">
                <input type="number" class="form-control" id="amount" name="amount" placeholder="Jumlah Order"/>
              </div>

              <h4 class="col-md-12"> Pilih bahan</h4>
              <div class="col-md-3 form-group jacket_material">
                <div class="radion_btn">
                  <input type="radio" id="f-option-material-1" name="selector_material" value="kain"/>
                  <label for="f-option-material-1">Kain</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_material">
                <div class="radion_btn">
                  <input type="radio" id="f-option-material-2" name="selector_material" value="kulit"/>
                  <label for="f-option-material-2">Kulit</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_material">
                <div class="radion_btn">
                  <input type="radio" id="f-option-material-3" name="selector_material" value="katun"/>
                  <label for="f-option-material-3">Katun</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>

              <h4 class="col-md-12"> Pilih warna</h4>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option1" name="selector_color" value="black"/>
                  <label for="f-option1">Black</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option2" name="selector_color" value="grey"/>
                  <label for="f-option2">Grey</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option3" name="selector_color" value="green army"/>
                  <label for="f-option3">Green Army</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option4" name="selector_color" value="cyan"/>
                  <label for="f-option4">Cyan</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option5" name="selector_color" value="donker"/>
                  <label for="f-option5">Donker</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option6" name="selector_color" value="cream"/>
                  <label for="f-option6">Cream</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option7" name="selector_color" value="dark red"/>
                  <label for="f-option7">Dark red</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>
              <div class="col-md-3 form-group jacket_color">
                <div class="radion_btn">
                  <input type="radio" id="f-option8" name="selector_color" value="white"/>
                  <label for="f-option8">white</label>
                  <div class="check"></div>
                </div>
                <!-- <img src="<?php echo e(asset('winter/img/instagram/inst_3.png')); ?>" alt="" style="width:200px;height:200px;"> -->
              </div>

              <h4 class="col-md-12"> Jacket Collar</h4>
              <div class="col-md-3 form-group jacket_collar">
                <div class="radion_btn">
                  <input type="radio" id="f-option-collar-1" name="selector_collar" value="kanva1"/>
                  <label for="f-option-collar-1">V model</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_collar">
                <div class="radion_btn">
                  <input type="radio" id="f-option-collar-2" name="selector_collar" value="kanva2"/>
                  <label for="f-option-collar-2">O model</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
            
              <h4 class="col-md-12"> Jacket Arm</h4>
              <div class="col-md-3 form-group jacket_arm">
                <div class="radion_btn">
                  <input type="radio" id="f-option-arm-1" name="selector_arm" value="kanva1"/>
                  <label for="f-option-arm-1">Short</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_arm">
                <div class="radion_btn">
                  <input type="radio" id="f-option-arm-2" name="selector_arm" value="kanva2"/>
                  <label for="f-option-arm-2">Long</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>

              <h4 class="col-md-12"> Jacket Arm Model</h4>
              <div class="col-md-3 form-group jacket_armmodel">
                <div class="radion_btn">
                  <input type="radio" id="f-option-armmodel-1" name="selector_armmodel" value="kanva1"/>
                  <label for="f-option-armmodel-1">karet</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_armmodel">
                <div class="radion_btn">
                  <input type="radio" id="f-option-armmodel-2" name="selector_armmodel" value="kanva2"/>
                  <label for="f-option-armmodel-2">biasa</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_armmodel">
                <div class="radion_btn">
                  <input type="radio" id="f-option-armmodel-3" name="selector_armmodel" value="kanva2"/>
                  <label for="f-option-armmodel-3">kancing</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>

              <h4 class="col-md-12"> Jacket Bag</h4>
              <div class="col-md-3 form-group jacket_bag">
                <div class="radion_btn">
                  <input type="radio" id="f-option-bag-1" name="selector_bag" value="kanva1"/>
                  <label for="f-option-bag-1">Kanan</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_bag">
                <div class="radion_btn">
                  <input type="radio" id="f-option-bag-2" name="selector_bag" value="kanva2"/>
                  <label for="f-option-bag-2">kiri</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_bag">
                <div class="radion_btn">
                  <input type="radio" id="f-option-bag-3" name="selector_bag" value="kanva2"/>
                  <label for="f-option-bag-3">kirikanan</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>

              <h4 class="col-md-12"> Pilih sleting/ kancing depan</h4>
              <div class="col-md-3 form-group jacket_zipper">
                <div class="radion_btn">
                  <input type="radio" id="f-option-zipper-1" name="selector_zipper" value="kanva1"/>
                  <label for="f-option-zipper-1">jenis1</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_zipper">
                <div class="radion_btn">
                  <input type="radio" id="f-option-zipper-2" name="selector_zipper" value="kanva2"/>
                  <label for="f-option-zipper-2">jenis2</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_zipper">
                <div class="radion_btn">
                  <input type="radio" id="f-option-zipper-3" name="selector_zipper" value="kanva2"/>
                  <label for="f-option-zipper-3">jenis3</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis3.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_zipper">
                <div class="radion_btn">
                  <input type="radio" id="f-option-zipper-4" name="selector_zipper" value="kanva2"/>
                  <label for="f-option-zipper-4">jenis4</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis4.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_zipper">
                <div class="radion_btn">
                  <input type="radio" id="f-option-zipper-5" name="selector_zipper" value="kanva2"/>
                  <label for="f-option-zipper-5">jenis5</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/formjaket/button/jenis5.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>

              <h4 class="col-md-12"> Jacket Button</h4>
              <div class="col-md-3 form-group jacket_button">
                <div class="radion_btn">
                  <input type="radio" id="f-option-button-1" name="selector_button" value="kanva1"/>
                  <label for="f-option-button-1">V model</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_1.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_button">
                <div class="radion_btn">
                  <input type="radio" id="f-option-button-2" name="selector_button" value="kanva2"/>
                  <label for="f-option-button-2">O model</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>
              <div class="col-md-3 form-group jacket_button">
                <div class="radion_btn">
                  <input type="radio" id="f-option-button-3" name="selector_button" value="kanva2"/>
                  <label for="f-option-button-3">Z model</label>
                  <div class="check"></div>
                </div>
                <img src="<?php echo e(asset('winter/img/instagram/inst_2.png')); ?>" alt="" style="width:200px;height:200px;">
              </div>

              

              <div class="col-md-12 form-group p_star">
                <h4>Jacket Size</h4>
                <select class="form-check" id="size" name="size">
                  <option value="S">S</option>
                  <option value="M">M</option>
                  <option value="L">L</option>
                  <option value="XL">XL</option>
                  <option value="XXL">XXL</option>
                </select>
              </div>

              <div class="col-md-12 form-group">
                  <h4>Desain Jacket</h4>
                  <div class="form-control">
                      <input type="file" name="jacket_design">
                  </div>
              </div>

              <div class="col-md-12 form-group">
                <h4>Order Jacket Note</h4>
                <textarea class="form-control" name="note" id="message" rows="1"
                  placeholder="Order Notes"></textarea>
              </div>


              <!-- <div class="col-md-12 form-group">
                <a class="btn_3 form-group" type=submit >Proceed</a>
              </div> -->
              <button type="submit" class="btn btn-success">
                Create
              </button>
              
              <input type="text" class="form-control" id="user_id" name="user_id" value="<?php echo e(Auth::getUser()->id); ?>" hidden/>
            </form>
          </div>
        </div>
      </div>
    </div>    
  </section>
  <!--================End Checkout Area =================-->

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>