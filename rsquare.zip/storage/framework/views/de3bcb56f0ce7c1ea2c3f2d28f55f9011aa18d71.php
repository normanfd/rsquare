<!-- Mendapatkan data cardigandata -->


<?php $__env->startSection('content'); ?>
<!-- <div class="m-content">
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Cardigan
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $cardigan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cardigandata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($cardigandata->user->name); ?> , <?php echo e($cardigandata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($cardigandata->amount); ?><br>
                                    Nomor WA : <?php echo e($cardigandata->wa_number); ?><br>
                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="<?php echo e(route('admin.detailcardiganorder', $cardigandata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                                 <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form> -->
                            <!-- </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    begin::Widget 14
                </div>
            </div>
        </div>
    </div>
</div> -->

<!-- <div class="m-content">
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Hoodie
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $hoodie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hoodiedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($hoodiedata->user->name); ?> , <?php echo e($hoodiedata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($hoodiedata->amount); ?> <br>
                                    Nomor WA : <?php echo e($hoodiedata->wa_number); ?> 
                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                            <a href="<?php echo e(route('admin.detailhoodieorder', $hoodiedata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                                <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form> -->
                            <!-- </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                    <!--begin::Widget 14-->
                <!-- </div>
            </div>
        </div>
    </div>
</div> -->

<div class="m-content">
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Jacket
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $jacket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jacketdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($jacketdata->user->name); ?>, <?php echo e($jacketdata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($jacketdata->amount); ?> <br>
                                    Nomor WA : <?php echo e($jacketdata->wa_number); ?>

                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                            <a href="<?php echo e(route('admin.detailjacketorder', $jacketdata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                                <!-- <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form> -->
                            </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--begin::Widget 14-->
                </div>
            </div>
        </div>
    </div>
<!-- </div>

<div class="m-content"> -->
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Shirt
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $shirt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($shirdata->user->name); ?>, <?php echo e($shirdata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($shirdata->amount); ?> <br>
                                    Nomor WA : <?php echo e($shirdata->wa_number); ?> <br>
                                
                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <!-- <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form> -->
                                <a href="<?php echo e(route('admin.detailshirtorder', $shirdata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                            </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--begin::Widget 14-->
                </div>
            </div>
        </div>
    </div>
<!-- </div>

<div class="m-content"> -->
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Shoes
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $shoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shoesdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($shoesdata->user->name); ?>, <?php echo e($shoesdata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($shoesdata->amount); ?> <br>
                                    Nomor WA : <?php echo e($shoesdata->wa_number); ?> <br>
                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <!-- <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form> -->
                                <a href="<?php echo e(route('admin.detailshoesorder', $shoesdata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                            </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--begin::Widget 14-->
                </div>
            </div>
        </div>
    </div>
<!-- </div> -->

<!-- <div class="m-content">
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order Sweater
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $sweater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sweaterdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($sweaterdata->user->name); ?>, <?php echo e($sweaterdata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">                                   
                                    Jumlah : <?php echo e($sweaterdata->amount); ?> <br>
                                    Nomor WA : <?php echo e($sweaterdata->wa_number); ?>

                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form>
                                <a href="<?php echo e(route('admin.detailsweaterorder', $sweaterdata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                            </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    begin::Widget 14
                </div>
            </div>
        </div>
    </div>
</div> -->

<!-- <div class="m-content"> -->
    <div class="m-portlet m-portlet--full-height ">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <h3 class="m-portlet__head-text">
                        Order T-Shirt
                    </h3>
                </div>
            </div>
        </div>
        <div class="m-portlet__body">
            <div class="tab-content">
                <div class="tab-pane active" id="m_widget4_tab1_content">

                <?php $__currentLoopData = $tshirt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tshirtdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="m-widget4">
                        <div class="m-widget4__item">
                            <div class="m-widget4__info">
                                <span class="m-widget4__title">
                                    <?php echo e($tshirtdata->user->name); ?>, <?php echo e($tshirtdata->created_at->format('l jS F Y')); ?>

                                </span>
                                <br>
                                <span class="m-widget4__sub">
                                    Jumlah : <?php echo e($tshirtdata->amount); ?> <br>
                                    Nomor WA : <?php echo e($tshirtdata->wa_number); ?> <br>
                                </span>
                            </div>
                            <div class="m-widget4__ext">
                                <a href="#" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Edit</a>
                            </div>
                            <div class="m-widget4__ext">
                                <form action="#" method="post">
                                    <button class="m-btn  btn btn-sm btn-info" type="submit">Detail</button>
                                </form>
                                <a href="<?php echo e(route('admin.detailtshirtorder', $tshirtdata->id)); ?>" class="m-btn m-btn--hover-brand btn btn-sm btn-primary">Detail</a>
                            </div>
                            
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--begin::Widget 14-->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>