sweater order detail
id sweater :{{ $single_sweater->id}}