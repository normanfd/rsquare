tshirt order detail
id tshirt :{{ $single_tshirt->id}}