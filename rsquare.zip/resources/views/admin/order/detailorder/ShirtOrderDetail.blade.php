shirt order detail
id shirt :{{ $single_shirt->id}}