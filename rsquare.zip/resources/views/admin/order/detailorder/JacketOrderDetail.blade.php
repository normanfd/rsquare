jaket Order detail
id jaket :{{ $single_jacket->id}}