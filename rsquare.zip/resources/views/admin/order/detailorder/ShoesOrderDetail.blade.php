shoes order detail
id shoes :{{ $single_shoes->id}}